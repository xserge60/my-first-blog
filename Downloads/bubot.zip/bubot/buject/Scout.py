from buject.Buject import Buject
import json
import time


class Scout(Buject):  # сервомотор без обратной связи
    def incoming_event_set_angle(self, message):
        data = json.loads(message['data'])
        self.send_request('set_angle_front_wheels', {'value': data['param']['value']*-1})

    def incoming_event_set_motor_power(self, message):
        data = json.loads(message['data'])
        self.status['cur_power'] = data['param']['value']
        self.send_request('set_power_rear_wheels', {'value': self.status['cur_power']})

    def incoming_event_change_camera_position(self, message):
        data = json.loads(message['data'])
        self.send_request('set_power_cameraX', {'value': data['param']['powerX']})
        self.send_request('set_power_cameraZ', {'value': data['param']['powerZ']})

    def incoming_event_change_motor_power(self, message):
        data = json.loads(message['data'])
        if self.status['cur_power'] > 0:
            self.status['cur_power'] = data['param']['value']
            self.send_request('set_power_rear_wheels', {'value': self.status['cur_power']})
        elif self.status['cur_power'] < 0:
            self.status['cur_power'] = data['param']['value']
            self.send_request('set_power_rear_wheels', {'value': self.status['cur_power']} * -1)

    def incoming_event_all_light(self, message):
        data = json.loads(message['data'])
        self.send_request("set_gpio", {"channel": self.param["GPIO_front_light"], "value": data['param']['value']})
        self.send_request("set_gpio", {"channel": self.param["GPIO_rear_light"], "value": data['param']['value']})


if __name__ == '__main__':
    buject = Scout()
    test = True

